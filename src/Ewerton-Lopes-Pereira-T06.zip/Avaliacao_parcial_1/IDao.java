package Avaliacao_parcial_1;

public interface IDao <T>{

    public T salvar(T t);
}
